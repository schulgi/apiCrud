package com.example.apicrud;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AutoDetalle  extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.autodetalle);

        Bundle bundle = getIntent().getExtras();

        String id = bundle.getString("id");

        Button btn_volver = (Button) findViewById(R.id.btn_volver);
        Button btn_actualizar = (Button) findViewById(R.id.btn_actualizar);
        Button btn_eliminar = (Button) findViewById(R.id.btn_eliminar);

        btn_volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AutoDetalle.this, MainActivity.class);

                startActivity(intent);

                //Toast.makeText(getApplicationContext(), "Pagina principal", Toast.LENGTH_LONG);
            }
        });

        AutoService autoService = ApiClient.getAutoService();

        Call<Auto> http_call = autoService.getAuto(id);

        http_call.enqueue(new Callback<Auto>() {
            @Override
            public void onResponse(Call<Auto> call, Response<Auto> response) {
                Auto auto = response.body();

                TextView txtId = (TextView) findViewById(R.id.txtId);
                if (auto!=null){
                    txtId.setText(auto.getId());
                }
                TextView txtMarca = (TextView) findViewById(R.id.txtMarca);
                if (auto!=null) {
                    txtMarca.setText(auto.getMarca());
                }
                TextView txtModelo = (TextView) findViewById(R.id.txtModelo);
                if (auto!=null) {
                    txtModelo.setText(auto.getModelo());
                }

            }

            @Override
            public void onFailure(Call<Auto> call, Throwable t) {
                Toast.makeText(AutoDetalle.this, "Hubo un error con la llamada a la API", Toast.LENGTH_LONG);
            }
        });


    }

}
